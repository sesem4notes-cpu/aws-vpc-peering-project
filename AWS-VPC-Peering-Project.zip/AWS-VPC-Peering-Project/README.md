# AWS VPC Peering Project

**Project:** Connect Two VPCs and Prove Private Connectivity  
**Platform:** Amazon Web Services (AWS)  
**Region:** `ap-south-1` (Mumbai, unless your lab instructor specifies another region)

## 1. Project overview
This project demonstrates private IPv4 connectivity between two Amazon VPCs using VPC Peering. A public bastion host in VPC A provides SSH administration access to two private EC2 application instances. Route tables and security groups control which traffic can pass.

> **Important:** This repository is a project starter/documentation pack. It does not claim that the AWS resources have already been deployed or tested. Add your own AWS console screenshots and real terminal output after you complete the lab.

## 2. Objectives
- Create two non-overlapping VPCs and their subnets.
- Keep both application EC2 instances private (no public IPv4 addresses).
- Create and activate a VPC peering connection.
- Configure forward and return routes.
- Use a bastion host for SSH administration.
- Verify connectivity with ping and SSH.
- Demonstrate a controlled failure by temporarily removing the App-B inbound ICMP Echo Request rule, then restoring it.
- Clean up lab resources to avoid unnecessary charges.

## 3. Architecture and IP plan

| Resource | CIDR / private IP | Notes |
|---|---|---|
| VPC A (`ewb-vpc-a`) | `10.10.0.0/16` | Has an Internet Gateway |
| Public subnet (`ewb-a-public`) | `10.10.1.0/24` | Bastion subnet |
| Private subnet A (`ewb-a-private`) | `10.10.2.0/24` | App-A |
| VPC B (`ewb-vpc-b`) | `10.20.0.0/16` | No Internet Gateway |
| Private subnet B (`ewb-b-private`) | `10.20.1.0/24` | App-B |
| Bastion (`ewb-bastion`) | `10.10.1.10` + public IPv4 | SSH entry point |
| App-A (`ewb-app-a`) | `10.10.2.10` | No public IPv4 |
| App-B (`ewb-app-b`) | `10.20.1.10` | No public IPv4 |

See `docs/architecture.svg` for a simple architecture diagram.

## 4. Required resources
- 2 VPCs
- 3 subnets
- 1 Internet Gateway attached to VPC A
- 3 custom route tables
- 3 security groups
- 3 EC2 instances (Amazon Linux 2023; use the lab-approved instance type)
- 1 EC2 key pair
- 1 VPC peering connection

## 5. Route table requirements
Keep AWS-created local routes. Add these routes after the peering connection becomes **Active**:

### `ewb-rt-a-private` (associated with `ewb-a-private`)
| Destination | Target |
|---|---|
| `10.10.0.0/16` | `local` (existing) |
| `10.20.0.0/16` | VPC peering connection ID (`pcx-...`) |

### `ewb-rt-b-private` (associated with `ewb-b-private`)
| Destination | Target |
|---|---|
| `10.20.0.0/16` | `local` (existing) |
| `10.10.0.0/16` | VPC peering connection ID (`pcx-...`) |

### `ewb-rt-a-public` (associated with `ewb-a-public`)
| Destination | Target |
|---|---|
| `10.10.0.0/16` | `local` (existing) |
| `0.0.0.0/0` | Internet Gateway (`igw-...`) |
| `10.20.0.0/16` | VPC peering connection ID (`pcx-...`) |

## 6. Security group inbound rules
Use the exact source addresses below only if the instance IPs match this plan. Do not expose SSH or ICMP to `0.0.0.0/0`.

| Security group | Protocol / port | Source |
|---|---|---|
| `ewb-sg-bastion` | SSH TCP 22 | Your current public IPv4 address with `/32` |
| `ewb-sg-app-a` | SSH TCP 22 | `10.10.1.10/32` |
| `ewb-sg-app-a` | ICMP Echo Request | `10.20.1.10/32` |
| `ewb-sg-app-b` | SSH TCP 22 | `10.10.1.10/32` |
| `ewb-sg-app-b` | ICMP Echo Request | `10.10.2.10/32` |

Keep the default outbound allow-all rule for this beginner lab and use the default network ACLs unless your instructor directs otherwise.

## 7. Implementation sequence
1. Create VPC A and its two subnets.
2. Attach an Internet Gateway to VPC A.
3. Create and associate the public and private route tables for VPC A.
4. Create VPC B and its private subnet and route table.
5. Create the three security groups.
6. Create the `ewb-lab` EC2 key pair and store the `.pem` file securely on your own computer.
7. Launch the bastion in the public subnet with a public IPv4 address.
8. Launch App-A and App-B in their private subnets without public IPv4 addresses.
9. Test the baseline ping from App-A to App-B before peering; save the real output.
10. Create and accept VPC peering; wait for `Active`.
11. Add the three peering routes listed above.
12. Test ping in both directions and SSH to App-B through the bastion.
13. Temporarily remove only App-B's inbound ICMP Echo Request rule from `10.10.2.10/32`; verify ping fails, then restore it and verify recovery.
14. Save screenshots and fill out `docs/testing-results-template.md`.
15. Clean up all lab resources after saving evidence.

## 8. Validation commands
Run commands on the appropriate EC2 host. Replace addresses only if your actual IP plan differs.

```bash
# Identify the current host
hostname
hostname -I

# From App-A, test App-B
ping -c 4 10.20.1.10

# From App-B, test App-A
ping -c 4 10.10.2.10
```

Expected acceptance criteria from the workbook: baseline ping before peering/routes gets no replies; after correct peering, routes and security rules, both directions should succeed; removing the destination ICMP rule should cause the ping to fail; restoring the rule should restore it. Record your **actual** outputs. These are expected outcomes, not pre-filled proof.

## 9. SSH through the bastion
Configure SSH on your own laptop/WSL/macOS/Linux machine. Keep the private key on your own computer; never upload the `.pem` file to GitHub.

Example `~/.ssh/config` (replace `BASTION_PUBLIC_IP` with your actual bastion public IP):

```sshconfig
Host ewb-bastion
    HostName BASTION_PUBLIC_IP
    User ec2-user
    IdentityFile ~/.ssh/ewb-lab.pem
    IdentitiesOnly yes

Host ewb-app-a
    HostName 10.10.2.10
    User ec2-user
    IdentityFile ~/.ssh/ewb-lab.pem
    IdentitiesOnly yes
    ProxyJump ewb-bastion

Host ewb-app-b
    HostName 10.20.1.10
    User ec2-user
    IdentityFile ~/.ssh/ewb-lab.pem
    IdentitiesOnly yes
    ProxyJump ewb-bastion
```

Then test `ssh ewb-bastion`, `ssh ewb-app-a`, and (after routes are configured) `ssh ewb-app-b`.

## 10. Cost and security notes
- AWS EC2, EBS and public IPv4 usage may incur charges. Check current pricing and account credits before launching.
- Use only the instructor-approved instance type.
- Restrict bastion SSH to your current public IPv4 `/32`.
- Do not publish private keys, passwords, account IDs, access tokens or other secrets.
- Terminate instances and remove lab networking resources when finished.

## 11. Repository checklist
- [ ] Replace this starter documentation with any instructor-required format.
- [ ] Add your own architecture screenshot/diagram if requested.
- [ ] Add actual AWS resource IDs and final IP addresses.
- [ ] Add actual screenshots to `screenshots/`.
- [ ] Fill in `docs/testing-results-template.md` with real results.
- [ ] Verify no private key or secret is included.
- [ ] Submit the repository URL using the internship Google Form.
