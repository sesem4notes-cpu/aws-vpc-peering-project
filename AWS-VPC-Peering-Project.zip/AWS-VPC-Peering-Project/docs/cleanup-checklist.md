# Cleanup Checklist

Save all evidence before deleting resources. Remove only resources created for this lab.

- [ ] Terminate `ewb-bastion`, `ewb-app-a`, and `ewb-app-b`.
- [ ] Check for leftover lab EBS volumes and snapshots.
- [ ] Release any Elastic IP allocated for the lab.
- [ ] Delete the lab key pair in AWS if no longer needed; remove the local key only if you are sure it is no longer needed.
- [ ] Remove routes pointing to the peering connection.
- [ ] Delete `ewb-a-b-peer`.
- [ ] Delete the three lab security groups after associated network interfaces are gone.
- [ ] Delete the three lab subnets and custom route tables.
- [ ] Detach and delete `ewb-igw-a`.
- [ ] Delete `ewb-vpc-a` and `ewb-vpc-b`.
- [ ] Check EC2, EBS, public IPv4 allocations and Billing for remaining resources.

AWS usage and billing reports may take time to update. Verify your account after cleanup.
