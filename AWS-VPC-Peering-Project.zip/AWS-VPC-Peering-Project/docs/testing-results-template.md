# Testing Results and Evidence

**Student name:** [Fill in]  
**Batch:** [Fill in]  
**AWS Region:** [Fill in]  
**Date performed:** [Fill in]

> Fill this template only after running the tests. Do not mark a test as passed without your own output/screenshot.

## Resource inventory
| Resource | Actual AWS ID | Actual IP/CIDR | Screenshot filename |
|---|---|---|---|
| VPC A | [vpc-...] | 10.10.0.0/16 | [filename] |
| VPC B | [vpc-...] | 10.20.0.0/16 | [filename] |
| Bastion | [i-...] | Public: [fill]; private: 10.10.1.10 | [filename] |
| App-A | [i-...] | 10.10.2.10 | [filename] |
| App-B | [i-...] | 10.20.1.10 | [filename] |
| Peering | [pcx-...] | Status: [Active/other] | [filename] |

## Test 1: Baseline before peering/routes
Command: `ping -c 4 10.20.1.10` from App-A  
Actual result: [Paste actual output or summarize]  
Outcome: [Pass if no replies as expected / Investigate]  
Evidence: `screenshots/[filename]`

## Test 2: Forward path after peering and routes
Command: `ping -c 4 10.20.1.10` from App-A  
Actual result: [Paste actual output or summarize]  
Outcome: [Fill in based on actual output]  
Evidence: `screenshots/[filename]`

## Test 3: Reverse path
Command: `ping -c 4 10.10.2.10` from App-B  
Actual result: [Paste actual output or summarize]  
Outcome: [Fill in based on actual output]  
Evidence: `screenshots/[filename]`

## Test 4: SSH to App-B through bastion
Command from laptop: `ssh ewb-app-b`  
Actual result: [Describe the shell prompt or actual error]  
Outcome: [Fill in]  
Evidence: `screenshots/[filename]`

## Test 5: Controlled ICMP failure and recovery
Action: Temporarily remove App-B's inbound ICMP Echo Request rule from `10.10.2.10/32`, keeping SSH allowed. Repeat Test 2, then restore the rule and repeat again.  
Actual result while rule removed: [Fill in]  
Actual result after rule restored: [Fill in]  
Evidence: `screenshots/[failure-filename]`, `screenshots/[recovery-filename]`

## Short explanation
**Forward path:** [Explain how App-A's route table sends `10.20.0.0/16` traffic to the peering connection.]  
**Return path:** [Explain how App-B's route table sends `10.10.0.0/16` traffic back through the same peering connection.]  
**Security:** [Explain how security groups restrict SSH and ICMP sources.]  
**Learning:** [Write 3-5 sentences in your own words.]
