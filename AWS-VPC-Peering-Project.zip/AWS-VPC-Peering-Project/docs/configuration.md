# Configuration Reference

## CIDR plan
- VPC A: `10.10.0.0/16`
- Public subnet A: `10.10.1.0/24`
- Private subnet A: `10.10.2.0/24`
- VPC B: `10.20.0.0/16`
- Private subnet B: `10.20.1.0/24`

The VPC CIDRs do not overlap, which is required for this peering design.

## Resource names
- VPCs: `ewb-vpc-a`, `ewb-vpc-b`
- Subnets: `ewb-a-public`, `ewb-a-private`, `ewb-b-private`
- Internet Gateway: `ewb-igw-a`
- Route tables: `ewb-rt-a-public`, `ewb-rt-a-private`, `ewb-rt-b-private`
- Security groups: `ewb-sg-bastion`, `ewb-sg-app-a`, `ewb-sg-app-b`
- Instances: `ewb-bastion`, `ewb-app-a`, `ewb-app-b`
- Key pair: `ewb-lab`
- Peering connection: `ewb-a-b-peer`

## Route logic
A route in App-A's private subnet points `10.20.0.0/16` to the peering connection. App-B's private route table needs the return route to `10.10.0.0/16`. The public subnet route table also needs a route to `10.20.0.0/16` because the bastion initiates its own SSH connection to App-B through ProxyJump.

## Security group logic
Security groups are stateful. The lab allows SSH from the bastion's private address to the private hosts and ICMP Echo Requests from the other private application host. Restrict bastion SSH to the student's current public IPv4 `/32`.

## Notes
- Replace placeholder IDs with actual AWS IDs in your report.
- Console labels may vary slightly.
- Do not treat this document as evidence that the project has been deployed.
